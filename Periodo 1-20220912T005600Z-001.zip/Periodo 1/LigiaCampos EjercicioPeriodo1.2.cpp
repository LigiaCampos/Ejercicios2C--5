#include<stdio.h>
main()
{
int i;
printf("Los numeros pares entre 10 y 20 inclusive son: \n");
for(i=10;i<=20;i=i+2)
    printf("%d \n",i);
return 0;
}
