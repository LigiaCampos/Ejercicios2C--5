#include<iostream>
using namespace std;

int main(){
	float limite, contador;
	cout << "ingrese el limite ";
	cin >> limite;
		while (contador < limite){
		contador = contador +1;
		cout << "Contador "<< contador << endl;
		}
}

